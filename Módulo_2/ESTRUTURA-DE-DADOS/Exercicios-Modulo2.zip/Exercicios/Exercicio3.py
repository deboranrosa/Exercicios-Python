# Escreva um programa Python para desempacotar uma tupla em várias variáveis:
# considere uma tupla = (‘aluno’,’universidade’, ‘nota’, ‘resultado’) e as variáveis w, x, y, z
# Consulte o tipo de dados de cada uma das variáveis e impriva os valores de cada uma
# delas.

# -*- coding: utf-8 -*-
w, x, y, z = 'aluno', 'universidade', 'nota', 'resultado'

print(type(w))
print(w)
print(type(x))
print(x)
print(type(y))
print(y)
print(type(z))
print(z)
