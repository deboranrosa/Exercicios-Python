def mensagem(texto):
    return print(texto)
