# Escreva um programa Python para criar uma tupla com números de 1 a 4 e imprima um item

# -*- coding: utf-8 -*-

numeros = 1, 2, 3, 4

for i in numeros:
    print(i)